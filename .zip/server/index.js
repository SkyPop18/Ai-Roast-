/**
 * server/index.js — Secure Gemini API proxy
 *
 * Env vars (loaded from server/.env):
 *   GEMINI_API_KEY   — required
 *   PORT             — default 3001
 *   NODE_ENV         — 'development' | 'production'
 *   ALLOWED_ORIGINS  — comma-separated list of allowed CORS origins
 */

import { config } from 'dotenv';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';

// Load server/.env explicitly so it works regardless of CWD
const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);
config({ path: join(__dirname, '.env') });

import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import morgan from 'morgan';
import rateLimit from 'express-rate-limit';
import { GoogleGenerativeAI } from '@google/generative-ai';

// ── Startup validation ────────────────────────────────────────────────────────
const GEMINI_API_KEY = process.env.GEMINI_API_KEY;
if (!GEMINI_API_KEY) {
  console.error('[FATAL] GEMINI_API_KEY is not set in server/.env — exiting.');
  process.exit(1);
}

const PORT = parseInt(process.env.PORT || '3001', 10);
const NODE_ENV = process.env.NODE_ENV || 'development';

// Parse allowed CORS origins from env (comma-separated)
const rawOrigins = process.env.ALLOWED_ORIGINS || 'http://localhost:5173,http://localhost:5174';
const allowedOrigins = rawOrigins.split(',').map((o) => o.trim()).filter(Boolean);

// ── Gemini SDK setup ──────────────────────────────────────────────────────────
const genAI = new GoogleGenerativeAI(GEMINI_API_KEY);
const geminiModel = genAI.getGenerativeModel({
  model: 'gemini-2.5-flash',
  generationConfig: {
    temperature: 0.85,
    maxOutputTokens: 1500,
    topP: 0.95,
    topK: 40,
  },
});

// ── Constants ─────────────────────────────────────────────────────────────────
const GEMINI_TIMEOUT_MS = 15_000;
const MAX_INPUT_LENGTH = 500;

const VALID_CATEGORIES = new Set([
  'General', 'Startup', 'Coding', 'Instagram',
  'Twitter', 'Dating', 'Business', 'Student', 'Gamer',
]);

const SYSTEM_PROMPT = `You are a professional comedian and roast master who specializes in savage, witty, internet-style roasts.

Generate a witty, clever, funny roast based on the provided text.

Rules:
- Roast the text, idea, or content itself — NEVER attack protected characteristics (race, gender, religion, etc.)
- Be funny, not hateful or genuinely cruel
- Use internet humor, memes, sarcasm, and sharp punchlines
- Maximum 200 words
- Make every roast memorable and quotable
- Use hyperbole for comedic effect
- End with one final devastating punchline that lands hard
- Keep it PG-13 — edgy but not offensive
- Reference specific details from the input for personalized roasts`;

// ── Helpers ───────────────────────────────────────────────────────────────────

/**
 * Race a promise against a timeout. Rejects with Error('TIMEOUT') if exceeded.
 */
function withTimeout(promise, ms) {
  let timeoutId;
  const timeout = new Promise((_, reject) => {
    timeoutId = setTimeout(() => reject(new Error('TIMEOUT')), ms);
  });
  return Promise.race([promise, timeout]).finally(() => clearTimeout(timeoutId));
}

function getDamageLevel(score) {
  if (score < 25) return { level: 1, label: 'Mild' };
  if (score < 50) return { level: 2, label: 'Medium' };
  if (score < 75) return { level: 3, label: 'Severe' };
  return { level: 4, label: 'Emotional Damage' };
}

// ── App setup ─────────────────────────────────────────────────────────────────
const app = express();

// Security headers (helmet sets ~15 headers incl. CSP, HSTS, X-Frame-Options, etc.)
app.use(helmet());

// CORS — only allow configured origins
app.use(
  cors({
    origin(origin, callback) {
      // Permit same-origin / non-browser requests (no Origin header)
      if (!origin) return callback(null, true);
      if (allowedOrigins.includes(origin)) return callback(null, true);
      // Log blocked origins server-side; return opaque error to caller
      console.warn(`[cors] Blocked request from origin: ${origin}`);
      callback(new Error('CORS_REJECTED'));
    },
    methods: ['GET', 'POST'],
    allowedHeaders: ['Content-Type'],
  })
);

// Request logging — 'combined' (Apache format) in prod, concise 'dev' otherwise
app.use(morgan(NODE_ENV === 'production' ? 'combined' : 'dev'));

// Parse JSON bodies; hard-cap at 10 KB to prevent large-payload attacks
app.use(express.json({ limit: '10kb' }));

// ── Rate limiter — applied per route ─────────────────────────────────────────
const roastLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 20,                  // max requests per window per IP
  standardHeaders: true,    // Return `RateLimit-*` headers
  legacyHeaders: false,
  message: { error: 'Too many requests. Please wait a few minutes and try again.' },
});

// ── Routes ────────────────────────────────────────────────────────────────────

// Health check — useful for uptime monitors and load balancers
app.get('/api/health', (_req, res) => {
  res.json({ status: 'ok', env: NODE_ENV, timestamp: new Date().toISOString() });
});

// Main roast endpoint
app.post('/api/roast', roastLimiter, async (req, res) => {
  const { input, category } = req.body;

  // --- Input validation ---
  if (!input || typeof input !== 'string') {
    return res.status(400).json({ error: 'Input is required and must be a string.' });
  }

  const trimmedInput = input.trim();

  if (trimmedInput.length === 0) {
    return res.status(400).json({ error: 'Input cannot be empty.' });
  }

  if (trimmedInput.length > MAX_INPUT_LENGTH) {
    return res
      .status(400)
      .json({ error: `Input is too long. Maximum ${MAX_INPUT_LENGTH} characters allowed.` });
  }

  if (category !== undefined && category !== null) {
    if (typeof category !== 'string' || !VALID_CATEGORIES.has(category)) {
      return res.status(400).json({ error: 'Invalid category provided.' });
    }
  }

  const safeCategory = (category && VALID_CATEGORIES.has(category)) ? category : 'General';
  const categoryContext =
    safeCategory !== 'General' ? ` This is a ${safeCategory} roast.` : '';

  const fullPrompt = `${SYSTEM_PROMPT}

Roast this:
"${trimmedInput}"
${categoryContext}

Respond ONLY with the roast text. No intro, no meta-commentary, just the roast.`;

  // --- Call Gemini (with timeout) ---
  try {
    let result;
    try {
      result = await withTimeout(geminiModel.generateContent(fullPrompt), GEMINI_TIMEOUT_MS);
    } catch (geminiErr) {
      if (geminiErr.message === 'TIMEOUT') {
        console.error('[roast] Gemini request timed out after', GEMINI_TIMEOUT_MS, 'ms');
        return res
          .status(504)
          .json({ error: 'The AI took too long to respond. Please try again.' });
      }
      // Gemini SDK error (quota, invalid key, network, etc.) — log it, hide it
      console.error('[roast] Gemini SDK error:', geminiErr.message);
      return res
        .status(502)
        .json({ error: 'The AI service is temporarily unavailable. Please try again shortly.' });
    }

    const roastText = result.response.text().trim();

    if (!roastText) {
      console.error('[roast] Gemini returned empty text for input length:', trimmedInput.length);
      return res
        .status(502)
        .json({ error: 'The AI returned an empty response. Please try different text.' });
    }

    const score = Math.floor(Math.random() * 40) + 55;
    const { level, label } = getDamageLevel(score);

    return res.json({
      roast: roastText,
      score,
      damageLevel: level,
      damageLabel: label,
    });
  } catch (err) {
    // Catch-all safety net — never expose internals to the client
    console.error('[roast] Unexpected error:', err);
    return res.status(500).json({ error: 'Something went wrong. Please try again.' });
  }
});

// ── 404 handler ───────────────────────────────────────────────────────────────
app.use((_req, res) => {
  res.status(404).json({ error: 'Not found.' });
});

// ── Global error handler ──────────────────────────────────────────────────────
// eslint-disable-next-line no-unused-vars
app.use((err, _req, res, _next) => {
  // Log the real error; return nothing sensitive
  console.error('[server] Unhandled error:', err.message);
  if (err.message === 'CORS_REJECTED') {
    return res.status(403).json({ error: 'Forbidden.' });
  }
  res.status(500).json({ error: 'Internal server error.' });
});

// ── Start ─────────────────────────────────────────────────────────────────────
app.listen(PORT, () => {
  console.log(`[server] ✅ Running in ${NODE_ENV} mode on port ${PORT}`);
  console.log(`[server] 🔒 CORS allowed origins: ${allowedOrigins.join(', ')}`);
});
