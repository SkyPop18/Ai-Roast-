/**
 * src/services/gemini.ts
 *
 * Frontend roast service — calls the backend /api/roast endpoint.
 * No API key, no direct Gemini calls, no SDK usage here.
 * All secret logic lives in server/index.js.
 */

export interface RoastResponse {
  roast: string;
  score: number;
  damageLevel: number; // 1–4
  damageLabel: string;
}

/**
 * Generate a roast by sending the user input to the backend proxy.
 * The backend handles the Gemini API call, key management, rate limiting,
 * and sanitized error responses.
 */
export async function generateRoast(input: string, category: string): Promise<RoastResponse> {
  const response = await fetch('/api/roast', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ input, category }),
  });

  // Parse the JSON body regardless of status so we can surface the error message
  const data = await response.json().catch(() => ({ error: 'Unexpected server response.' }));

  if (!response.ok) {
    // The backend always returns { error: string } — never raw internals
    throw new Error(data?.error || `Request failed (${response.status})`);
  }

  return data as RoastResponse;
}

// ── Example inputs shown in the UI (no API involvement) ───────────────────────
export const EXAMPLE_INPUTS = [
  "My startup uses AI blockchain to disrupt the disruption of disruptive markets, targeting a $10 trillion addressable market.",
  "Just launched my Instagram fitness page! 3 followers, 2 are my mom's accounts. Posting daily inspiration ✨💪🌟",
  "function getUserData() { return fetch('/api').then(r => r.json()).catch(e => null) }",
  "Looking for my soulmate who loves long walks on the beach, Netflix marathons, and 'going with the flow'.",
  "Hot take: pineapple on pizza is actually good because it provides essential vitamins and we should all be more open-minded.",
  "Been grinding for 6 months. No days off. 4am wake-ups. Still broke but my mindset is worth millions.",
];
