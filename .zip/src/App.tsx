import { useState, useEffect, useCallback, useRef } from 'react';
import { AnimatePresence } from 'framer-motion';
import { generateRoast } from './services/gemini';
import type { RoastResponse } from './services/gemini';
import { useLocalStorage } from './hooks/useAnimations';

// Components
import { Navbar } from './components/Navbar';
import { FloatingDecos } from './components/FloatingDecos';
import { HeroSection, Marquee } from './components/HeroSection';
import { CategorySelector } from './components/CategorySelector';
import { RoastInput } from './components/RoastInput';
import { RoastResult } from './components/RoastResult';
import { StatsSection } from './components/StatsSection';
import { RoastHistory, makeHistoryEntry } from './components/RoastHistory';
import type { HistoryEntry } from './components/RoastHistory';
import { Toast } from './components/Toast';
import { Footer } from './components/Footer';

interface ToastState {
  id: number;
  message: string;
  type: 'success' | 'error' | 'info';
}

function App() {
  // State
  const [darkMode, setDarkMode] = useLocalStorage('darkMode', false);
  const [inputText, setInputText] = useState('');
  const [category, setCategory] = useState('Startup');
  const [isLoading, setIsLoading] = useState(false);
  const [result, setResult] = useState<RoastResponse | null>(null);
  const [toasts, setToasts] = useState<ToastState[]>([]);
  const [history, setHistory] = useLocalStorage<HistoryEntry[]>('roastHistory', []);
  const [stats, setStats] = useLocalStorage('roastStats', {
    totalRoasts: 42189,
    usersEmoDamaged: 39847,
    avgBurnTemp: 4500,
    todaysVictims: 217,
  });
  const resultRef = useRef<HTMLDivElement>(null);

  // Dark mode effect
  useEffect(() => {
    document.documentElement.setAttribute('data-theme', darkMode ? 'dark' : 'light');
  }, [darkMode]);

  // Toast helper
  const showToast = useCallback((message: string, type: 'success' | 'error' | 'info' = 'success') => {
    const id = Date.now();
    setToasts(t => [...t.slice(-2), { id, message, type }]);
  }, []);

  const dismissToast = useCallback((id: number) => {
    setToasts(t => t.filter(x => x.id !== id));
  }, []);

  // Handle roast generation
  const handleRoast = useCallback(async () => {
    if (!inputText.trim() || isLoading) return;

    setIsLoading(true);
    setResult(null);

    try {
      const roastResult = await generateRoast(inputText.trim(), category);
      setResult(roastResult);

      // Save to history
      const entry = makeHistoryEntry(inputText.trim(), category, roastResult);
      setHistory(prev => [entry, ...prev].slice(0, 20));

      // Update stats
      setStats(prev => ({
        totalRoasts: prev.totalRoasts + 1,
        usersEmoDamaged: prev.usersEmoDamaged + (roastResult.damageLevel >= 3 ? 1 : 0),
        avgBurnTemp: Math.min(prev.avgBurnTemp + Math.floor(Math.random() * 50), 9999),
        todaysVictims: prev.todaysVictims + 1,
      }));

      // Scroll to result
      setTimeout(() => {
        resultRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }, 300);

    } catch (err: any) {
      showToast(
        err?.message?.includes('API')
          ? '⚡ API error — check your connection'
          : `Error: ${err?.message || 'Something went wrong'}`,
        'error'
      );
    } finally {
      setIsLoading(false);
    }
  }, [inputText, category, isLoading, showToast, setHistory, setStats]);

  // Global keyboard shortcut
  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') {
        e.preventDefault();
        if (!isLoading && inputText.trim()) handleRoast();
      }
    };
    window.addEventListener('keydown', handler);
    return () => window.removeEventListener('keydown', handler);
  }, [handleRoast, isLoading, inputText]);

  // Copy roast
  const handleCopy = useCallback(() => {
    if (!result?.roast) return;
    navigator.clipboard.writeText(result.roast).then(() => {
      showToast('Roast copied to clipboard! 📋', 'success');
    }).catch(() => {
      showToast('Could not copy — try manually', 'error');
    });
  }, [result, showToast]);

  // Share roast
  const handleShare = useCallback(() => {
    if (!result?.roast) return;
    const text = `🔥 I got roasted by AI!\n\n"${result.roast.slice(0, 200)}..."\n\nScore: ${result.score}/100 — ${result.damageLabel}\n\nGet roasted: https://airoast.ai`;
    if (navigator.share) {
      navigator.share({ title: '🔥 My AI Roast', text });
    } else {
      navigator.clipboard.writeText(text).then(() => {
        showToast('Share text copied! Paste it anywhere 🔗', 'success');
      });
    }
  }, [result, showToast]);

  // Load history entry
  const handleSelectHistory = useCallback((entry: HistoryEntry) => {
    setInputText(entry.input);
    setCategory(entry.category);
    setResult({
      roast: entry.roast,
      score: entry.score,
      damageLevel: entry.damageLevel,
      damageLabel: entry.damageLabel,
    });
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, []);

  const handleClearHistory = useCallback(() => {
    setHistory([]);
    showToast('History cleared 🗑', 'info');
  }, [setHistory, showToast]);

  return (
    <div style={{ position: 'relative', minHeight: '100vh' }}>
      {/* Background Decorations */}
      <FloatingDecos />

      {/* Navbar */}
      <Navbar
        darkMode={darkMode}
        onToggleDark={() => setDarkMode(d => !d)}
      />

      {/* Marquee */}
      <Marquee />

      {/* Main content */}
      <main style={{ position: 'relative', zIndex: 1 }}>
        {/* Hero */}
        <HeroSection />

        {/* Divider */}
        <div className="brut-divider" />

        {/* Category Selector */}
        <CategorySelector selected={category} onSelect={setCategory} />

        {/* Input Section */}
        <RoastInput
          value={inputText}
          onChange={setInputText}
          onRoast={handleRoast}
          isLoading={isLoading}
        />

        {/* Result Section */}
        <div ref={resultRef}>
          <AnimatePresence mode="wait">
            {result && (
              <RoastResult
                key={result.roast}
                result={result}
                onCopy={handleCopy}
                onShare={handleShare}
                showToast={showToast}
              />
            )}
          </AnimatePresence>
        </div>

        {/* Second divider */}
        <div className="brut-divider" />

        {/* Stats Section */}
        <StatsSection stats={stats} />

        {/* History */}
        <RoastHistory
          history={history}
          onSelectEntry={handleSelectHistory}
          onClear={handleClearHistory}
        />
      </main>

      {/* Footer */}
      <Footer />

      {/* Toasts */}
      <div style={{
        position: 'fixed',
        bottom: '24px',
        right: '24px',
        zIndex: 9999,
        display: 'flex',
        flexDirection: 'column',
        gap: '10px',
        alignItems: 'flex-end',
      }}>
        <AnimatePresence>
          {toasts.map(t => (
            <Toast
              key={t.id}
              message={t.message}
              type={t.type}
              onClose={() => dismissToast(t.id)}
            />
          ))}
        </AnimatePresence>
      </div>
    </div>
  );
}

export default App;
