import React, { useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { EXAMPLE_INPUTS } from '../services/gemini';

interface RoastInputProps {
  value: string;
  onChange: (v: string) => void;
  onRoast: () => void;
  isLoading: boolean;
}

const MAX_CHARS = 800;

const THINKING_PHRASES = [
  '🧠 AI is crafting your destruction...',
  '💀 Sharpening the roast...',
  '😈 Preparing maximum damage...',
  '🔥 Loading savage mode...',
  '🎯 Taking careful aim at your soul...',
];

export const RoastInput: React.FC<RoastInputProps> = ({
  value, onChange, onRoast, isLoading
}) => {
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const [thinkingIdx, setThinkingIdx] = React.useState(0);
  const [buttonPressed, setButtonPressed] = React.useState(false);

  // Rotate thinking phrases
  useEffect(() => {
    if (!isLoading) return;
    const t = setInterval(() => {
      setThinkingIdx(i => (i + 1) % THINKING_PHRASES.length);
    }, 1500);
    return () => clearInterval(t);
  }, [isLoading]);



  const handleRandom = () => {
    const r = EXAMPLE_INPUTS[Math.floor(Math.random() * EXAMPLE_INPUTS.length)];
    onChange(r);
    textareaRef.current?.focus();
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') {
      e.preventDefault();
      if (!isLoading && value.trim()) onRoast();
    }
  };

  const handleButtonClick = () => {
    if (isLoading || !value.trim()) return;
    setButtonPressed(true);
    setTimeout(() => setButtonPressed(false), 200);
    onRoast();
  };

  const charCount = value.length;
  const charPct = charCount / MAX_CHARS;
  const charColor = charPct > 0.9 ? '#ff5252' : charPct > 0.7 ? '#ff9800' : 'var(--brut-text)';

  return (
    <section style={{ padding: '0 0 40px' }}>
      <div className="container">
        <motion.div
          className="brut-card"
          style={{
            background: 'var(--brut-surface)',
            boxShadow: 'var(--brut-shadow-xl)',
            padding: '32px',
          }}
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.3 }}
        >
          {/* Card header */}
          <div style={{
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'center',
            marginBottom: '16px',
            flexWrap: 'wrap',
            gap: '10px',
          }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
              <span style={{
                display: 'inline-block',
                background: 'var(--brut-primary)',
                color: '#fff',
                fontWeight: 900,
                fontSize: '0.75rem',
                textTransform: 'uppercase',
                letterSpacing: '1.5px',
                padding: '4px 12px',
                border: 'var(--brut-border-thick)',
              }}>
                ENTER TARGET
              </span>
            </div>
            <button
              className="brut-btn brut-btn-yellow brut-btn-sm"
              onClick={handleRandom}
              type="button"
              disabled={isLoading}
            >
              🎲 Random Example
            </button>
          </div>

          {/* Textarea */}
          <textarea
            ref={textareaRef}
            className="brut-textarea"
            placeholder="Paste your startup idea, Instagram bio, code, tweet, pickup line, or life decisions..."
            value={value}
            onChange={e => onChange(e.target.value.slice(0, MAX_CHARS))}
            onKeyDown={handleKeyDown}
            rows={6}
            disabled={isLoading}
            style={{ resize: 'vertical', minHeight: '160px', maxHeight: '320px' }}
          />

          {/* Footer */}
          <div style={{
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'center',
            marginTop: '12px',
            flexWrap: 'wrap',
            gap: '12px',
          }}>
            {/* Char counter */}
            <div style={{
              fontFamily: 'var(--font-mono)',
              fontWeight: 700,
              fontSize: '0.85rem',
              color: charColor,
              transition: 'color 0.3s',
            }}>
              {charCount} / {MAX_CHARS} chars
              {charCount === 0 && (
                <span style={{ opacity: 0.5, marginLeft: '10px' }}>
                  ← type something, coward
                </span>
              )}
            </div>

            {/* Roast Button */}
            <motion.button
              className="brut-btn brut-btn-xl"
              onClick={handleButtonClick}
              disabled={isLoading || !value.trim()}
              animate={buttonPressed ? { x: 6, y: 6 } : { x: 0, y: 0 }}
              whileHover={!isLoading && value.trim() ? { x: 2, y: 2 } : {}}
              style={{
                boxShadow: buttonPressed ? 'none' : 'var(--brut-shadow-xl)',
                transition: 'box-shadow 0.15s',
              }}
            >
              {isLoading ? (
                <span style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                  <span className="loading-dots">
                    <span /><span /><span />
                  </span>
                  ROASTING...
                </span>
              ) : (
                <>🔥 ROAST ME</>
              )}
            </motion.button>
          </div>

          {/* Thinking animation */}
          <AnimatePresence>
            {isLoading && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: 'auto' }}
                exit={{ opacity: 0, height: 0 }}
                style={{
                  marginTop: '16px',
                  padding: '12px 16px',
                  border: 'var(--brut-border-thick)',
                  background: 'var(--brut-secondary)',
                  fontFamily: 'var(--font-mono)',
                  fontWeight: 700,
                  fontSize: '0.9rem',
                  display: 'flex',
                  alignItems: 'center',
                  gap: '10px',
                }}
              >
                <motion.span
                  animate={{ rotate: 360 }}
                  transition={{ duration: 1, repeat: Infinity, ease: 'linear' }}
                  style={{ display: 'inline-block', fontSize: '1.2rem' }}
                >
                  ⚡
                </motion.span>
                <AnimatePresence mode="wait">
                  <motion.span
                    key={thinkingIdx}
                    initial={{ opacity: 0, y: -5 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: 5 }}
                    transition={{ duration: 0.3 }}
                  >
                    {THINKING_PHRASES[thinkingIdx]}
                  </motion.span>
                </AnimatePresence>
              </motion.div>
            )}
          </AnimatePresence>
        </motion.div>
      </div>
    </section>
  );
};
