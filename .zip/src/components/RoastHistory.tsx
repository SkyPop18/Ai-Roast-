import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import type { RoastResponse } from '../services/gemini';

interface HistoryEntry {
  id: string;
  input: string;
  roast: string;
  score: number;
  damageLevel: number;
  damageLabel: string;
  category: string;
  timestamp: number;
}

interface RoastHistoryProps {
  history: HistoryEntry[];
  onSelectEntry: (entry: HistoryEntry) => void;
  onClear: () => void;
}

const SKULL_SETS: Record<number, string> = { 1: '☠', 2: '☠☠', 3: '☠☠☠', 4: '☠☠☠☠' };
const DAMAGE_COLORS: Record<number, string> = {
  1: '#42e695', 2: '#ffe156', 3: '#ff9800', 4: '#ff5252',
};

export const RoastHistory: React.FC<RoastHistoryProps> = ({ history, onSelectEntry, onClear }) => {
  if (history.length === 0) return null;

  return (
    <section style={{ padding: '40px 0 60px' }}>
      <div className="container">
        <div className="section-title-wrap" style={{ marginBottom: '24px' }}>
          <h2 style={{ fontSize: 'clamp(1.5rem, 4vw, 2.2rem)', whiteSpace: 'nowrap' }}>
            📜 ROAST HISTORY
          </h2>
          <div className="section-title-bar" />
          <button
            className="brut-btn brut-btn-black brut-btn-sm"
            onClick={onClear}
            style={{ flexShrink: 0 }}
          >
            🗑 Clear
          </button>
        </div>

        <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
          <AnimatePresence>
            {history.slice(0, 8).map((entry, i) => (
              <motion.div
                key={entry.id}
                className="history-item"
                onClick={() => onSelectEntry(entry)}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: 20 }}
                transition={{ delay: i * 0.04 }}
                whileTap={{ scale: 0.99 }}
              >
                <div style={{
                  display: 'flex',
                  justifyContent: 'space-between',
                  alignItems: 'flex-start',
                  gap: '12px',
                  flexWrap: 'wrap',
                }}>
                  <div style={{ flex: 1, minWidth: 0 }}>
                    {/* Input preview */}
                    <div style={{
                      fontWeight: 700,
                      fontSize: '0.9rem',
                      marginBottom: '4px',
                      overflow: 'hidden',
                      textOverflow: 'ellipsis',
                      whiteSpace: 'nowrap',
                      opacity: 0.7,
                    }}>
                      📝 {entry.input.slice(0, 80)}{entry.input.length > 80 ? '...' : ''}
                    </div>
                    {/* Roast preview */}
                    <div style={{
                      fontFamily: 'var(--font-mono)',
                      fontSize: '0.85rem',
                      fontWeight: 600,
                      overflow: 'hidden',
                      textOverflow: 'ellipsis',
                      whiteSpace: 'nowrap',
                    }}>
                      🔥 {entry.roast.slice(0, 100)}{entry.roast.length > 100 ? '...' : ''}
                    </div>
                  </div>

                  {/* Meta */}
                  <div style={{
                    display: 'flex',
                    flexDirection: 'column',
                    alignItems: 'flex-end',
                    gap: '4px',
                    flexShrink: 0,
                  }}>
                    <span style={{
                      background: DAMAGE_COLORS[entry.damageLevel],
                      border: 'var(--brut-border-thick)',
                      padding: '2px 10px',
                      fontWeight: 800,
                      fontSize: '0.75rem',
                      letterSpacing: '0.5px',
                    }}>
                      {SKULL_SETS[entry.damageLevel]} {entry.damageLabel}
                    </span>
                    <span style={{
                      fontFamily: 'var(--font-mono)',
                      fontSize: '0.75rem',
                      fontWeight: 700,
                      opacity: 0.5,
                    }}>
                      {new Date(entry.timestamp).toLocaleTimeString()}
                    </span>
                  </div>
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
        </div>
      </div>
    </section>
  );
};

// Convert RoastResponse + input into a HistoryEntry
export function makeHistoryEntry(
  input: string,
  category: string,
  result: RoastResponse
): HistoryEntry {
  return {
    id: `${Date.now()}-${Math.random().toString(36).slice(2)}`,
    input,
    roast: result.roast,
    score: result.score,
    damageLevel: result.damageLevel,
    damageLabel: result.damageLabel,
    category,
    timestamp: Date.now(),
  };
}

export type { HistoryEntry };
