import React from 'react';
import { motion } from 'framer-motion';

export const CATEGORIES = [
  { id: 'Startup', label: 'Startup Roast',    emoji: '🚀' },
  { id: 'Coding',  label: 'Coding Roast',     emoji: '💻' },
  { id: 'Instagram', label: 'Instagram Roast', emoji: '📸' },
  { id: 'Twitter', label: 'Twitter Roast',    emoji: '🐦' },
  { id: 'Dating',  label: 'Dating Roast',     emoji: '💔' },
  { id: 'Business', label: 'Business Roast',  emoji: '💼' },
  { id: 'Student', label: 'Student Roast',    emoji: '📚' },
  { id: 'Gamer',   label: 'Gamer Roast',      emoji: '🎮' },
];

interface CategorySelectorProps {
  selected: string;
  onSelect: (id: string) => void;
}

export const CategorySelector: React.FC<CategorySelectorProps> = ({ selected, onSelect }) => {
  return (
    <section style={{ padding: '40px 0' }}>
      <div className="container">
        {/* Section title */}
        <div className="section-title-wrap">
          <h2 style={{ fontSize: 'clamp(1.5rem, 4vw, 2.2rem)', whiteSpace: 'nowrap' }}>
            🎯 CHOOSE YOUR ROAST
          </h2>
          <div className="section-title-bar" />
        </div>

        <div className="grid-4" style={{ gap: '16px' }}>
          {CATEGORIES.map((cat, i) => (
            <motion.div
              key={cat.id}
              className={`category-card ${selected === cat.id ? 'selected' : ''}`}
              onClick={() => onSelect(cat.id)}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.05, duration: 0.3 }}
              whileTap={{ scale: 0.97 }}
            >
              <span style={{ fontSize: '1.4rem', flexShrink: 0 }}>{cat.emoji}</span>
              <span style={{ fontSize: '0.85rem', fontWeight: 800 }}>{cat.label}</span>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};
